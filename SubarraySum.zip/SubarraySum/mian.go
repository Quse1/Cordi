/*Given an array of integers and an integer target, find a subarray that sums to target and return the start and end indices of the subarray.
Input: arr: 1 -20 -3 30 5 4 target: 7
Output: 1 4
Explanation: -20 - 3 + 30 = 7. The indices for subarray [-20,-3,30] is 1 and 4 (right exclusive).*/

package main

import "fmt"

func SubarraySum(nums []int, target int) []int {
	if len(nums) == 0 {
		return []int{}
	}
	prefixSum := make(map[int]int)
	var curSum int
	for i := 0; i < len(nums); i++ {
		curSum += nums[i]
		if curSum == target {
			return []int{0, i + 1}
		}
		complement := curSum - target
		if start, inMap := prefixSum[complement]; inMap {
			return []int{start, i + 1}
		}
		prefixSum[curSum] = i + 1

	}
	return []int{}
}

func main() {
	var nums []int = []int{1, -20, -3, 30, 5, 4}
	var target int = 7
	fmt.Println(SubarraySum(nums, target))
}
