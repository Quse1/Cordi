// Рефлексия (отражение) предназначена для взаимодействии разных типов данных, заранее неизвестных при компиляции проекта. Создания API, которые будут использоваться в других проектах.

package main

import (
	"reflect"
	"strings"
)

/*reflect.Type предоставляет методы для получения информации о типе, такие как:
Kind(): возвращает основную категорию типа (например, int, string, struct, slice и т.д.).
Name(): возвращает имя типа, если это возможно.
NumField(): возвращает количество полей в структуре.
Field(i int): возвращает информацию о поле структуры по индексу.*/

/*func getTypePath(t reflect.Type) (path string) {
	path = t.PkgPath() // возвращает путь пакета для типа. Если тип int, bool возвращает пустую строку
	if path == "" {
		path = "(built-in)"
	}
	return
}

/*var intPtrType = reflect.TypeOf((*int)(nil))
var byteSliceType = reflect.TypeOf([]byte(nil))

func printDetails(values ...interface{}) {
	for _, elem := range values {
		elemValue := reflect.ValueOf(elem)
		elemType := reflect.TypeOf(elem)
		if elemType == intPtrType {
			Printfln("Pointer to Int: %v", elemValue.Elem().Int())
		} else if elemType == byteSliceType {
			Printfln("Byte slice: %v", elemValue.Bytes())
		} else {
			switch elemValue.Kind() {
			case reflect.Bool:
				var val bool = elemValue.Bool()
				Printfln("Bool: %v", val)
			case reflect.Int:
				var val int64 = elemValue.Int()
				Printfln("Int: %v", val)
			case reflect.Float32, reflect.Float64:
				var val float64 = elemValue.Float()
				Printfln("Float: %v", val)
			case reflect.String:
				var val string = elemValue.String()
				Printfln("String: %v", val)
			/*case reflect.Ptr:
			var val reflect.Value = elemValue.Elem()
			if val.Kind() == reflect.Int {
				Printfln("Pointer to Int: %v", val.Int())
			}
			default:
				Printfln("Other: %v", elemValue.String())
			}
		}
		//var fieldDetails []string
		//elemType := reflect.TypeOf(elem) // Тип входящих данных
		//Printfln("Name: %v, PkgPath: %v, Kind: %v", elemType.Name(), getTypePath(elemType), elemType.Kind())
		/*fmt.Println("Обозначение типа: ", elemType)
		elemValue := reflect.ValueOf(elem)
		//fmt.Println("Значения типа: ", elemValue)
		if elemType.Kind() == reflect.Struct {
			//fmt.Println("Kind определяет название типа: ", elemType.Kind())
			for i := 0; i < elemType.NumField(); i++ {
				fmt.Println("Количество  полей переменных в типе: ", elemType.NumField())
				fieldName := elemType.Field(i).Name
				fmt.Println("Название переменной указанного типа: ", fieldName)
				fieldVal := elemValue.Field(i)
				fmt.Println("Значение переменной структуры: ", fieldVal)
				fieldDetails = append(fieldDetails, fmt.Sprintf("%v, %v", fieldName, fieldVal))
			}
			Printfln("%v: %v", elemType.Name(), strings.Join(fieldDetails, ": "))
		} else {
			Printfln("%v: %v", elemType.Name(), elemValue)
		}
	}
}
type Payment struct {
	Currency string
	Amount   float64
}
// SelectValue функция выбирает значения из среза, не зная типа элемента среза
func selectValue(data interface{}, index int) (result interface{}) {
	dataVal := reflect.ValueOf(data)
	if dataVal.Kind() == reflect.Slice {
		result = dataVal.Index(index).Interface() // .interface() используется для получения значения, которое можно использовать в качестве результата
		fmt.Println(result)
	}
	return
}*/

func incrementOrUpper(values ...interface{}) {
	for _, elem := range values {
		elemValue := reflect.ValueOf(elem)
		if elemValue.Kind() == reflect.Ptr {
			elemValue = elemValue.Elem()
		}
		if elemValue.CanSet() {
			switch elemValue.Kind() {
			case reflect.Int:
				elemValue.SetInt(elemValue.Int() + 1)
			case reflect.String:
				elemValue.SetString(strings.ToUpper(elemValue.String()))
			}
			Printfln("Modified Value: %v", elemValue)
		} else {
			Printfln("Cannot set %v: %v", elemValue.Kind(), elemValue)
		}
	}
}

func setAll(src interface{}, targets ...interface{}) {
	srcVal := reflect.ValueOf(src)
	for _, target := range targets {
		targetVal := reflect.ValueOf(target)
		if targetVal.Kind() == reflect.Ptr && targetVal.Elem().Type() == srcVal.Type() && targetVal.Elem().CanSet() {
			targetVal.Elem().Set(srcVal)
		}
	}
}

func main() {
	/*product := Product{
		Name: "Kayak", Category: "Watersports", Price: 279,
	}
	customer := Customer{Name: "Alice", City: "New York"}
	payment := Payment{Currency: "USD", Amount: 100.5}
	mass := [3]int{3, 6, 7}
	number := 100
	slice := []byte("Alice")
	printDetails(true, 10, 23.30, "Alice", &number, product, slice)
	names := []string{"Alice", "Bob", "Charlie"}
	val := selectValue(names, 1).(string)
	Printfln("Selected: %v", val)*/

	name := "Alice"
	price := 279
	city := "London"

	//incrementOrUpper(&name, &price, &city)

	setAll("New String", &name, &price, &city)
	setAll(10, &name, &price, &city)

	for _, val := range []interface{}{name, price, city} {
		Printfln("Value: %v", val)
	}

	//names := []string{"Alice", "Bob", "Charlie"}
	//val := selectValue(names, 1).(string)
	//Printfln("Selected: %v", val)

}
