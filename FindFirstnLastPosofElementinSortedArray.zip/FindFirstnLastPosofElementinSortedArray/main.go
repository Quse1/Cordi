package main

import "fmt"

func FirstIndex(nums []int, target int) int {
	var start, end int = 0, len(nums) - 1
	var mid, fidx int = 0, -1

	for start <= end {
		mid = start + (end-start)/2
		if nums[mid] == target {
			fidx = mid
			end = mid - 1
		} else if nums[mid] < target { // Если значение в middle меньше target, значит искомое значение
			// находится в правой половине массива, и левая граница сдвигается вправо (left = middle + 1)
			start = mid + 1
		} else {
			end = mid - 1
		}
	}
	return fidx
}

func LastIndex(nums []int, target int) int {
	var start, end int = 0, len(nums) - 1
	var mid, lidx int = 0, -1
	for start <= end {
		mid = start + (end-start)/2
		if nums[mid] == target {
			lidx = mid
			start = mid + 1
		} else if nums[mid] > target { // Если значение в middle больше target, то искомое значение
			// находится в левой половине, и правая граница сдвигается влево (right = middle - 1)
			end = mid - 1
		} else {
			start = mid + 1
		}
	}
	return lidx

}

func searchRange(nums []int, target int) []int {
	var FstLst []int = []int{-1, -1}
	FstLst[0] = FirstIndex(nums, target)
	FstLst[1] = LastIndex(nums, target)

	return FstLst

}

func main() {
	var nums []int = []int{2, 2}
	var target int = 2
	fmt.Println(searchRange(nums, target))

}
