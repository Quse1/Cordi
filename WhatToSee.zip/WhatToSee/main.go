package main

import (
	"fmt"
	"sort"
	"strings"
)

/*
Вам необходимо реализовать функцию printRecommendations, которая будет анализировать данные о фильмах и рекомендовать их к просмотру на основе заданных критериев.
Функция должна принимать вложенный map[string]map[string]float64, где ключи первого уровня представляют жанры фильмов, а ключи второго уровня — названия фильмов
с их соответствующими рейтингами.

Условия
Функция должна принимать один аргумент movies типа map[string]map[string]float64, где:

Ключ первого уровня (string) — это название жанра (например, "Экшен", "Драма").
Ключ второго уровня (string) — это название фильма.
Значение (float64) — это рейтинг фильма.
Функция должна выводить на экран все жанры в алфавитном порядке, в которых есть хотя бы один фильм с рейтингом 7 и выше.

Для каждого жанра, в котором есть фильмы с рейтингом 7 и выше, необходимо вывести названия всех фильмов (с рейтингом 7 и выше) в порядке убывания их рейтинга, если
рейтинг одинаков, тогда сортировать такие фильмы нужно в алфавитном порядке.

Если в жанре нет фильмов с рейтингом 7 и выше, в таком случае, жанр вовсе не должен выводиться.

Ожидаемый вывод:

Драма: Фильм4 (7.5), Фильм3 (7.5).
Экшен: Фильм1 (8.5).
*/

func printRecommendations(m map[string]map[string]float64) {
	filmrate := make(map[string]float64)
	movies := make(map[string]string)
	var genres []string
	var f []string
	for genre, films := range m {
		genres = append(genres, genre)
		for film, rate := range films {
			if rate >= 7.0 {
				f = append(f, film)
				sort.Strings(f)
				for i := range f {
					filmrate[f[i]] = rate
				}
			}

		}
	}

	for genre, films := range m {
		for film, rate := range films {
			if _, inMap := filmrate[film]; inMap {
				movies[genre] += fmt.Sprintf("%s (%.1f), ", film, rate)
			}
		}
	}

	sort.Strings(genres)
	for i := range genres {
		movies[genres[i]] = strings.TrimSuffix(movies[genres[i]], ", ")
		fmt.Printf("%s: %s.\n", genres[i], movies[genres[i]])

	}
}

func main() {
	m := map[string]map[string]float64{
		"Экшен": {
			"Фильм1": 8.52,
			"Фильм2": 6.0,
		},
		"Комедия": {
			"Фильм66": 9.72,
			"Фильм34": 4.0,
		},
		"Драма": {
			"Фильм3": 7.524,
			"Фильм4": 7.527,
			"Фильм5": 5.54,
		},
	}

	printRecommendations(m)

}
