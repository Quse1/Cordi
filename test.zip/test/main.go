package main

import (
	"errors"
	"fmt"
	"math/rand/v2"
)

func CreateSlice(n int) ([]int, error) {
	if n < 0 {
		return []int{}, errors.New("число n отрицательное")
	}

	numbers := make([]int, n)

	for i := 0; i < n; i++ {
		numbers[i] = rand.IntN(21) - 10
	}
	fmt.Println(FilterSlice(numbers))
	return numbers, nil
}

func FilterSlice(numbers []int) []int {
	var nums []int

	for i := 1; i < len(numbers); i++ {
		if numbers[i-1] > numbers[i] {
			if numbers[i]%2 == 0 || numbers[i]%5 == 0 || numbers[i]%6 == 0 || numbers[i]%9 == 0 {
				nums = append(nums, numbers[i])
			}
		}
	}
	return nums
}

func MaxSumWithNegative(numbers []int, k int) []int {

}

func main() {
	var n int = 10
	fmt.Println(CreateSlice(n))

}
