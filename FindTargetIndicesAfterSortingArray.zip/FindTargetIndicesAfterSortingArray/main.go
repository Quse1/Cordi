package main

import "fmt"

func BubbleSort(nums []int) []int {
	var isSwapper bool = true

	if len(nums) <= 1 {
		return nums
	}

	for {
		isSwapper = false
		for i := 1; i < len(nums); i++ {
			if nums[i-1] > nums[i] {
				nums[i-1], nums[i] = nums[i], nums[i-1]
				isSwapper = true
			}
		}
		if !isSwapper {
			break
		}
	}
	return nums
}

func targetIndices(nums []int, target int) []int {
	BubbleSort(nums)
	var start, end int = 0, len(nums) - 1
	var idx []int
	for start <= end {
		if nums[start] == target {
			idx = append(idx, start)
		}
		start++

	}
	return idx
}

func main() {
	var nums []int = []int{1, 2, 2, 5, 3}
	var target int = 5
	fmt.Println(targetIndices(nums, target))

}
