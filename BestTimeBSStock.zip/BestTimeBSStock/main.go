package main

import (
	"fmt"
)

func Max(profit int, n int) int {
	if profit < n {
		profit = n
	}
	return profit
}

func maxProfit(prices []int) int {
	var profit int

	buy := prices[0]
	for _, sell := range prices[1:] {
		if sell > buy { // последующая цена должна быть больше предыдущей
			profit = Max(profit, sell-buy) // определяем прибыль
		} else {
			buy = sell

		}

	}
	return profit
}

func main() {
	var prices []int = []int{7, 6, 4, 3, 1}
	fmt.Println(maxProfit(prices))
}
