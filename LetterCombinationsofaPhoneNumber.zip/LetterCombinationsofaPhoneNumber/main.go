/* Объяснение изменений
Передача указателя на срез: В функции dfs мы изменили тип параметра combinations на *[]string. Это позволяет функции изменять оригинальный срез, переданный из функции letterCombinations.
Обновление среза: Внутри функции dfs теперь используется *combinations = append(*combinations, current) для добавления новой комбинации.

Заключение
Теперь ваш код корректно генерирует все возможные комбинации букв для заданной строки цифр. Использование рекурсии и указателей позволяет эффективно
 управлять состоянием программы и сохранять результаты. Если у вас есть дополнительные вопросы или нужно помочь с другими задачами, дайте знать!*/

package main

import "fmt"

// Функция для выполнения DFS
func dfs(digits string, combinations *[]string, index int, current string) {
	digitToChars := map[rune]string{
		'2': "abc",
		'3': "def",
		'4': "ghi",
		'5': "jkl",
		'6': "mno",
		'7': "pqrs",
		'8': "tuv",
		'9': "wxyz",
	}

	if index == len(digits) {
		*combinations = append(*combinations, current) // Используем указатель для обновления среза
		return
	}

	letters := digitToChars[rune(digits[index])]
	for _, letter := range letters {
		dfs(digits, combinations, index+1, current+string(letter))
	}
}

// Функция для генерации комбинаций букв
func letterCombinations(digits string) []string {
	var combinations []string
	if len(digits) == 0 {
		return []string{}
	}

	dfs(digits, &combinations, 0, "") // Передаем указатель на срез
	return combinations
}

func main() {
	digits := "234"
	result := letterCombinations(digits)
	fmt.Println(result) // Ожидаемый вывод: ["ad","ae","af","bd","be","bf","cd","ce","cf"]
}
