package main

import (
	"bufio"
	"fmt"
	"os"
	"strings"
	"unicode"
)

func GetInput() (string, error) {
	reader, err := bufio.NewReader(os.Stdin).ReadString('\n')
	if err != nil {
		return "", fmt.Errorf("ошибка ввода %w", err)
	}
	if len(reader) == 0 {
		return "", fmt.Errorf("пустой ввод строки %w", err)
	}

	return strings.TrimSpace(reader), nil
}

func CountCharacters(text string) (letters int, digits int, spaces int, punctuation int) {
	for _, char := range text {
		switch {
		case unicode.IsLetter(char):
			letters++
		case unicode.IsDigit(char):
			digits++
		case unicode.IsSpace(char):
			spaces++
		case unicode.IsPunct(char):
			punctuation++
		}
	}
	return
}

func DisplayResults(letters, digits, spaces, punctuation int) {
	fmt.Printf("Количество букв: %v\n", letters)
	fmt.Printf("Количество цифр: %v\n", digits)
	fmt.Printf("Количество пробелов: %v\n", spaces)
	fmt.Printf("Количество знаков препинания: %v\n", punctuation)
}

func main() {
	text, err := GetInput()
	if err != nil {
		return
	}
	letters, digits, spaces, punctuation := CountCharacters(text)
	DisplayResults(letters, digits, spaces, punctuation)
}
