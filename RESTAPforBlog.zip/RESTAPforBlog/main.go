package main

/*
REST API для блога (Gin + PostgreSQL)
Реализовал CRUD для статей с JWT-аутентификацией.
Использовал Docker для развертывания.
*/

import (
//"bufio"
	"fmt"
//"os"
//"strconv"
//"strings"
	"github.com/google/uuid"
)

/*const (
	create = "create"
	read = "read"
	update = "update"
	delet = "delete"
	exite = "exite"
)*/

func main() {
	/*var message []string = []string{
		"Ошибка 503: Сервис временно недоступен. Попробуйте позже.",
		"Каждая проблема — это замаскированная возможность. Не сдавайся!",
		"Фиолетовые бегемоты танцуют под дождём из конфетти.",
		"Привет! Как твои дела? Готов к сегодняшнему митингу?",
		"ERROR: duplicate key value violates unique constraint 'users_pkey'",
		"Только сегодня! Скидка 30% на все курсы по Go. Успей купить!",
		"Если дерево падает в лесу, но никто не слышит, издает ли оно звук?",
		"Релиз переносится на завтра — нужно пофиксить баг с авторизацией.",
		"Космические еноты захватили серверы AWS. Это не шутка.",
	}*/

	/*messages := &Messages{
		ID: uuid.New(),
		Lists:  make(map[uuid.UUID]string),
	}*/

	num := uuid.New()
	fmt.Println(num)

	/*for {
	scanner := bufio.NewScanner(os.Stdin)
	scanner.Scan()
	input := scanner.Text()
	input = strings.TrimSpace(input)
	input = strings.ToLower(input)
	switch input {
	case create:
		scanner.Scan()
		text := scanner.Text()
		text = strings.TrimSpace(text)
		_, err := messages.CreateMessage(text)
		if err != nil {
			return
		}
		/*for k, v := range mes.Lists {
			fmt.Printf("%d: %s\n", k, v)
		}
	case read:
		messages.ReadMessages()
	case update:
		scanner.Scan()
		text := scanner.Text()
		text = strings.TrimSpace(text)
		scanner.Scan()
		numbers := scanner.Text()
		num, err := strconv.Atoi(numbers)
		if err != nil {
			fmt.Println("ошибка конвертации", err)
			return
		}
		mes, err := messages.UpdateMessages(num, text)
	if err != nil {
		fmt.Println("ошибка обновления", err)
		return
	}
	fmt.Println(mes)*/
	
	/*case delet:
		scanner.Scan()
		numbers := scanner.Text()
		num, err := strconv.Atoi(numbers)
		if err != nil {
			return
		}
	_, err = messages.DeleteMessages(num)
	if err != nil {
		return 
	}
case exite:
	return
}
	}*/
}
