package main

import (
	"errors"
	"fmt"
//	"slices"
	"github.com/google/uuid"
)

type Messages struct {
	ID     uuid.UUID
	Lists  map[uuid.UUID]string
}

func (m *Messages) CreateMessage(message string) (*Messages, error) {
	if message == "" {
		return nil, errors.New("пустое сообщение")
	}
	m.ID = uuid.New()
	m.Lists[m.ID] = message
	return m, nil
}

func (m Messages) ReadMessages() {
	for k, v := range m.Lists {
			fmt.Printf("%d: %s\n", k[len(k)-12], v)
	}
}

func (m *Messages) UpdateMessages(id int, message string) (*Messages, error) {
	for k := range m.Lists {
		if id != int(k[len(k)-12]) {
		return nil, errors.New("номера id нет в списке сообщений")
	}
}
	m.Lists[m.ID] = message
	return m, nil
}

func (m *Messages) DeleteMessages(id int) (*Messages, error) {
			if _, inMap := m.Lists[m.ID]; inMap {
				delete(m.Lists, m.ID)
				//m.IDList = slices.Delete(m.IDList, id, id+1)
				return m, nil
			}
	return nil, errors.New("удалить сообщение не удалось")
}
