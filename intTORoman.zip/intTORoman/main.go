package main

import (
	"fmt"
)

/*func myPow(x int, n int) int {
	var step int = 1
	if n == 0 || x == 1 {
		return 1
	}
	if x == 0 {
		return 0
	}
	if n < 0 && x != 1 {
		n = -n
		x = 1 / x
	}
	for n > 0 {
		if n%2 == 1 {
			step *= x
		}
		x *= x
		n /= 2
	}
	return step
}*/

func intToRoman(num int) string {
	var RomanS []string = []string{"M", "CM", "D", "CD", "C", "XC", "L", "XL", "X", "IX", "V", "IV", "I"}
	var RomanI []int = []int{1000, 900, 500, 400, 100, 90, 50, 40, 10, 9, 5, 4, 1}
	var r string
	for k, v := range RomanI {
		for num >= v {
			r += RomanS[k]
			num -= v
		}
	}
	return r

}

func main() {
	var num int = 58
	fmt.Println(intToRoman(num))

}
