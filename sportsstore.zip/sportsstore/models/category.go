package models 

type Category struct {
	ID int 
	CategoryName string
}