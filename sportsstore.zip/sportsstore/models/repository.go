package models

type Repository interface {
	GetProduct(id int) Product
	GeProducts() []Product
	GetCategories() []Category
	Seed()
}
