/*Problem Description
This problem asks us to find all the unique triplets in an array that can combine to give a sum of zero. A triplet in this context is defined as a set of
three numbers [nums[i], nums[j], nums[k]] where each number comes from a different position in the array, indicated by i, j, and k. Importantly, we need to ensure that:

The indices i, j, and k are all different.
The sum of the numbers at those indices is zero (nums[i] + nums[j] + nums[k] == 0).
No triplet is repeated in the result.

Our goal is to identify all such combinations, ensuring that each combination of three numbers is unique within the result set. This problem is a classic example of a
challenge involving array manipulation and the identification of specific patterns within a numerical set.

Intuition
To arrive at the solution for this problem, we will follow a two-step approach. First, we sort the array in non-decreasing order. The sorting helps us in two ways:
it makes it easy to avoid adding duplicate triplets and allows us to use the two-pointer technique effectively.

After sorting, the array is processed with a loop that effectively tries out each number as a potential candidate for the first number of the triplet.
This candidate is referred to as nums[i]. Starting from i = 0, we will check whether nums[i], when added to any two other numbers in the array to its right, sums to zero.

To expedite the process and avoid checking combinations that are guaranteed to fail or are redundant, we make use of the following insights:

If the current number nums[i] is greater than zero, because the array is sorted, any combination involving this and subsequent numbers will be greater than zero.
 Since no sum with a positive total can equal zero, we can break out of the loop early.

If nums[i] is the same as the previous number nums[i-1], we skip the current value to prevent processing the same triplet scenario, which would lead to duplicates.

Once a valid nums[i] is chosen, we employ a while loop using two pointers, j and k, that start after i (for j) and at the end of the array (for k).
We calculate the sum of nums[i], nums[j], and nums[k]. If the sum is:
Less than zero, we move j to the right to increase the sum (nums[j] will be larger).
Greater than zero, we shift k to the left to decrease the sum (because nums[k] will get smaller).
Exactly zero, we have found a valid triplet and add it to our solution set. We then move both j and k pointers, skipping over any duplicates to look for additional triplets starting with nums[i].
We repeat this process for every index i until the second last element, and collect all unique triplets that give us a sum of zero.*/

package main

import (
	"fmt"
	"slices"
)

func threeSum(nums []int) [][]int {
	slices.Sort(nums)

	var triplets [][]int
	n := len(nums)
	// Запускаем внешний цикл, который проходит по каждому элементу массива до предпоследнего элемента (индекс n-2). Этот элемент будет фиксированным (первая часть триплета).
	for i := 0; i < n-2; i++ {
		// Если текущий элемент равен предыдущему (nums[i] == nums[i-1]), пропускаем итерацию. Это предотвращает добавление одинаковых триплетов.
		if i > 0 && nums[i] == nums[i-1] {
			continue
		}
		// Устанавливаем целевое значение target, равное отрицательному значению текущего элемента. Это значение будет использоваться
		// для поиска двух других элементов, которые в сумме с текущим элементом дадут ноль.
		target := -nums[i]
		// Создаем хэш-таблицу (карта) numMap, которая будет хранить значения элементов и их индексы. Это поможет быстро проверять наличие нужных значений.
		numMap := make(map[int]int)

		// Запускаем внутренний цикл, который проходит по оставшимся элементам массива, начиная с элемента после фиксированного (i + 1).
		for j := i + 1; j < n; j++ {
			// Вычисляем значение currentsum, которое равно разности между целевым значением и текущим элементом nums[j].
			// Это значение представляет собой число, которое мы ищем в карте.
			currentsum := target - nums[j]
			// Проверяем, существует ли currentsum в карте numMap. Если да, значит мы нашли два числа: текущее число nums[j] и число из карты,
			// которые в сумме дают ноль вместе с фиксированным числом nums[i].
			if _, inMap := numMap[currentsum]; inMap {
				//fmt.Println(numMap)
				//fmt.Println(numMap)
				triplets = append(triplets, []int{nums[i], nums[j], currentsum})
				// Пропускаем все дубликаты для элемента j, чтобы избежать добавления одинаковых триплетов в результат.
				for j < n-1 && nums[j] == nums[j+1] {
					j++
				}
			}
			// Добавляем текущее число nums[j] и его индекс в карту numMap.
			numMap[nums[j]] = j
			//fmt.Println(nums[j], j)
		}
	}
	return triplets
}

/*func threeSum(nums []int) [][]int {
	slices.Sort(nums)
	var triplets [][]int
	var start, end int
	n := len(nums)
	//Iterate through the array.
	for i := 0; i < n-2; i++ {
		// If the current number is greater than 0, since the array is sorted,
		// no three numbers can add up to zero.
		if nums[i] > 0 {
			break
		}
		// Skip the same element to avoid duplicate triplets.
		if i > 0 && nums[i] == nums[i-1] {
			continue
		}
		// Set the two pointers, one just after the current element,
		// and the other at the end of the array.
		start = i + 1
		end = n - 1
		// While the left pointer is less than the right pointer.
		for start < end {
			// Calculate the sum of the current three elements.
			current_sum := nums[i] + nums[start] + nums[end]
			// If the sum is less than zero, move the left pointer to the right.
			if current_sum < 0 {
				start++
				// If the sum is greater than zero, move the right pointer to the left.
			} else if current_sum > 0 {
				end--
				// If the sum is zero, we've found a valid triplet.
			} else {
				// Add the triplet to the result.
				triplets = append(triplets, []int{nums[i], nums[start], nums[end]})
				// Move both the left and right pointers to continue searching.
				start++
				end--
				// Skip duplicate elements by moving the left pointer to the right.
				for start < end && nums[start] == nums[start-1] {
					start++
				}
				// Skip duplicate elements by moving the right pointer to the left.
				for start > end && nums[end] == nums[end+1] {
					end--
				}

			}

		}
	}
	// Return the list of found triplets.
	return triplets
}*/

func main() {
	var nums []int = []int{-1, 0, 1, 2, -1, -4, -2, -3, 3, 0, 4} // [[-4,0,4],[-4,1,3],[-3,-1,4],[-3,0,3],[-3,1,2],[-2,-1,3],[-2,0,2],[-1,-1,2],[-1,0,1]]
	fmt.Println(threeSum(nums))
}
