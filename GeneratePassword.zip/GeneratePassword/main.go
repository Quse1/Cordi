package main

import (
	"errors"
	"fmt"
	"math/rand/v2"
	//"strings"
)

const (
	MinPasswordLength = 4
	MinPasswordsCount = 1
	MaxPasswordsCount = 50
)

var (
	ErrPasswordLengthTooLow = errors.New("password length too low")
	ErrTooLowPasswordsCount = errors.New("too low passwords count")
	ErrTooBigPasswordsCount = errors.New("too big passwords count")
)

var (
	upperChars   = []rune("ABCDEFGHIJKLMNOPQRSTUVWXYZ") // По крайней мере одну заглавную букву (A-Z)
	lowerChars   = []rune("abcdefghijklmnopqrstuvwxyz") // По крайней мере одну строчную букву (a-z)
	digitChars   = []rune("0123456789")                 // По крайней мере одну цифру (0-9)
	specialChars = []rune("!@#$%^&*")                   // По крайней мере один специальный символ (например, !@#$%^&*)
)

func generatePassword(length, count int) ([]string, error) {
	if length < MinPasswordLength {
		return nil, ErrPasswordLengthTooLow
	}
	if count < MinPasswordsCount {
		return nil, ErrTooLowPasswordsCount
	}
	if count > MaxPasswordsCount {
		return nil, ErrTooBigPasswordsCount
	}
	var CountPassword []string
	var AllChars []rune

	AllChars = append(AllChars, upperChars...)
	AllChars = append(AllChars, lowerChars...)
	AllChars = append(AllChars, digitChars...)
	AllChars = append(AllChars, specialChars...)

	for k := 0; k < count; k++ {
		password := make([]string, length)

		for i := range length {
			index := rand.IntN(len(AllChars))
			password[i] = string(AllChars[index])
		}
		CountPassword = append(CountPassword, password)

	}

	return CountPassword, nil

}

func main() {
	passwords, err := generatePassword(12, 5)
	if err != nil {
		return
	}
	for _, pass := range passwords {
		fmt.Println(pass)
	}
	generatePassword(12, 5)

}
