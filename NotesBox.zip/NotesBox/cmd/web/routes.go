package main

import (
	"net/http"
)

func (app *application) routes() *http.ServeMux {
	mux := http.NewServeMux()
	mux.HandleFunc("/", app.home)
	mux.HandleFunc("/notes", app.showNotes)
	mux.HandleFunc("/notes/create", app.createNotes)

	fileServer := http.FileServer(http.Dir("C:/Users/Aleksei1lph/Documents/GOProjects/NotesBox/ui/static"))
	mux.Handle("/static/", http.StripPrefix("/static", fileServer))

	return mux
}
