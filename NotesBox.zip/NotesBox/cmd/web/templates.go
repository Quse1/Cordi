package main 

import (
	"NotesBox/pkg/models"
)


type templateData struct {
Note *models.Notes
Notes []*models.Notes

}