package main

import (
	"encoding/json"
	"fmt"
	"os"
)

// Чтение JSON файла
/*func main() {
	file, err := os.Open("people.json")
	if err != nil {
		fmt.Println("Ошибка открытия файла:", err)
		return
	}
	defer file.Close()

	var data []map[string]interface{}

	decoder := json.NewDecoder(file)
	err = decoder.Decode(&data)
	if err != nil {
		fmt.Println("Ошибка декодирования данных JSON", err)
		return
	}
	for _, r := range data {
		fmt.Printf("Имя: %s, Возраст: %v, Города: %s \n", r["name"], r["age"], r["city"])

	}
}*/

// Запись данных в новый JSON файл
/*func main() {
	file, err := os.Create("products.json")
	if err != nil {
		fmt.Println("Ошибка создания файла", err)
		return
	}
	defer file.Close()

	data := []map[string]interface{}{
		{"name": "Молоко", "quantity": 2, "price": 100},
		{"name": "Хлеб", "quantity": 1, "price": 40},
		{"name": "Сыр", "quantity": 1, "price": 300},
		{"name": "Кофе", "quantity": 3, "price": 500},
		{"name": "Шоколад", "quantity": 10, "price": 150},
	}

	encoder := json.NewEncoder(file)
	err = encoder.Encode(data)
	if err != nil {
		fmt.Println("Ошибка кодирования данных Go в файл JSON", err)
		return
	}
	fmt.Println("Данные успешно записаны в файл!")
}*/

// Добавление данных в JSON файл
/*func main() {
	file, err := os.Open("records.json")
	if err != nil {
		fmt.Println("Ошибка файл не открылся", err)
		return
	}
	defer file.Close()

	var data []map[string]interface{}

	decoder := json.NewDecoder(file)
	err = decoder.Decode(&data)
	if err != nil {
		fmt.Println("Ошибка чтения данных JSON  в  тип данных Go", err)
		return
	}

	new_data := []map[string]interface{}{
		{"name": "Мария", "age": 22, "city": "Киев"},
		{"name": "Алексей", "age": 35, "city": "Лондон"},
		{"name": "Светлана", "age": 29, "city": "Бристоль"},
	}

	data = append(data, new_data...)

	file, err = os.Create("records.json")
	if err != nil {
		fmt.Println("Ошибка файл не открылся", err)
		return
	}
	defer file.Close()

	encoder := json.NewEncoder(file)
	err = encoder.Encode(data)
	if err != nil {
		fmt.Println("Ошибка кодирования данных Go в файл JSON", err)
		return
	}
	fmt.Println("Данные успешно записаны в файл!")
}*/

// Подсчёт объектов в JSON файле
/*func main() {
	file, err := os.Open("transactions.json")
	if err != nil {
		fmt.Println("Ошибка файл не открылся", err)
		return
	}
	defer file.Close()

	var records []map[string]interface{}

	decoder := json.NewDecoder(file)
	err = decoder.Decode(&records)
	if err != nil {
		fmt.Println("Ошибка чтения данных JSON в тип данных Go", err)
		return
	}
	fmt.Printf("Количество транзакций: %v", len(records))
}*/

// Объединение двух JSON файлов
func main() {
	file, err := os.Create("merge.json")
	if err != nil {
		fmt.Println("Ошибка файл не открылся", err)
		return
	}
	defer file.Close()

	files := []string{"file1.json", "file2.json"}

	var data []map[string]interface{}

	//var new_data []map[string]interface{}

	for _, f := range files {
		fn, err := os.Open(f)
		if err != nil {
			fmt.Println("Ошибка файл не открылся", err)
			return
		}
		defer fn.Close()

		decoder := json.NewDecoder(fn)
		err = decoder.Decode(&data)
		if err != nil {
			fmt.Println("Ошибка чтения данных JSON в тип данных Go", err)
			return
		}
		//new_data = append(new_data, data...)

		for _, r := range data {
			fmt.Printf("Имя: %s, Возраст: %v \n", r["name"], r["age"])

		}
	}

	/*encoder := json.NewEncoder(file)
	err = encoder.Encode(new_data)
	if err != nil {
		fmt.Println("Ошибка кодирования данных Go в файл JSON", err)
		return
	}
	fmt.Println("Данные успешно записаны в файл!")*/

}
