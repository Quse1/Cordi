package main

import (
	"fmt"
	"slices"
	"strings"
)

// Реализуйте функцию countFriends, которая принимает map с пользователями и их друзьями и возвращает map, где ключом является имя
// пользователя, а значением — количество его друзей.
func countFriends(friendsData map[string][]string) map[string]int {
	cFriends := make(map[string]int)
	//var max int
	for name, friends := range friendsData {
		var count int
		for i := 0; i < len(friends); i++ {
			count++
		}
		cFriends[name] = count
		//fmt.Printf("%s: %d\n", name, count)
	}
	//fmt.Println(cFriends)
	return cFriends
}

// Реализуйте функцию commonFriends, которая принимает map с пользователями и их друзьями, а также имена двух пользователей.
// Функция должна возвращать список общих друзей между этими двумя пользователями.
// Общие друзья между пользователями Иван и Елена: Алексей, Дмитрий.
func commonFriends(friendsData map[string][]string, ListNames []string) string {
	var FriendList [][]string
	for i := 0; i < len(ListNames); i++ {
		if v, inMap := friendsData[ListNames[i]]; inMap {
			FriendList = append(FriendList, v)
		}
	}

	general := make(map[string]int)
	var GeneralList []string

	for _, friend := range FriendList {
		for i := range friend {
			general[friend[i]]++
		}
	}
	for k, v := range general {
		if v == len(ListNames) {
			GeneralList = append(GeneralList, k)
		}

	}

	return fmt.Sprintf("Общие друзья между пользователями %s: %s.", strings.Join(ListNames, " и "), strings.Join(GeneralList, ", "))
}

// Реализуйте функцию mostPopularUsers, которая принимает map с пользователями и их друзьями и возвращает список имен пользователей с
// наибольшим количеством друзей и это количество.
// Наиболее популярные пользователи: Алексей, Дмитрий, Елена, Иван (количество друзей: 3).
func mostPopularUsers(friendsData map[string][]string) ([]string, string) {
	friends := countFriends(friendsData)
	var max int
	var ListNames []string
	for friend, count := range friends {
		if max < count {
			max = count
			ListNames = []string{friend} // очищаетcя список ListNames, когда находится и добавляется новый пользователь с большим количеством друзей
		} else if max == count {
			ListNames = append(ListNames, friend)
		}
	}
	slices.Sort(ListNames)

	Names := strings.Join(ListNames, ", ")

	text := fmt.Sprintf("Наиболее популярные пользователи: %s (количество друзей: %d)", Names, max)

	return ListNames[2:], text // Список общих друзей между двумя заданными пользователями
}

func main() {
	friendsData := map[string][]string{
		"Алексей":  {"Иван", "Сергей", "Елена"},
		"Иван":     {"Алексей", "Дмитрий", "Мария"},
		"Сергей":   {"Алексей", "Елена"},
		"Дмитрий":  {"Иван", "Елена", "Ольга"},
		"Елена":    {"Алексей", "Сергей", "Дмитрий"},
		"Мария":    {"Иван", "Ольга"},
		"Ольга":    {"Дмитрий", "Мария"},
		"Анна":     {"Петр"},
		"Петр":     {"Анна", "Сергей"},
		"Светлана": {"Иван", "Елена"},
	}
	fmt.Println("Количество друзей:")
	for name, count := range countFriends(friendsData) {
		fmt.Printf("%s: %d\n", name, count)
	}
	fmt.Println()
	names, text := mostPopularUsers(friendsData)
	fmt.Println(text)
	fmt.Println(commonFriends(friendsData, names))

}
