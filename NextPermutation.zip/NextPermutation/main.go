package main

import (
	"fmt"
)

func reverse(nums []int) {
	left, right := 0, len(nums)-1
	for left < right {
		nums[left], nums[right] = nums[right], nums[left]
		left++
		right--
	}
}

func nextPermutation(nums []int) []int {
	var pivot int = -1

	if len(nums) <= 1 {
		return nums
	}

	for i := len(nums) - 2; i >= 0; i-- {
		//fmt.Println(nums[i], nums[i+1])
		if nums[i] < nums[i+1] {
			pivot = i
			break
		}
	}
	//fmt.Println(pivot)
	if pivot != -1 {
		for j := len(nums) - 1; j >= pivot; j-- {
			if nums[j] > nums[pivot] {
				nums[pivot], nums[j] = nums[j], nums[pivot]
				break
			}

		}
	}
	reverse(nums[pivot+1:])
	//slices.Reverse(nums[pivot+1:])
	return nums
}

func main() {
	var nums []int = []int{1, 2} //Output: [1,3,2]
	fmt.Println(nextPermutation(nums))
}

/*Input: nums = [3,2,1]
Output: [1,2,3]

Input: nums = [1,1,5]
Output: [1,5,1]*/
