package main

import (
	"math/rand"
	"strings"

	tgbotapi "github.com/go-telegram-bot-api/telegram-bot-api/v5"
)

const TOKEN = "7684328425:AAH0qKfUXt5zZxnIF1oc3Uqp4LUnjnh8Xks"

var bot *tgbotapi.BotAPI

var fortuneTellerNames = [3]string{"стивен", "стив", "кинг"}

var answers = []string{
	"Да",
	"Нет",
	"Страх — это не враг. Он просто сигнализирует о том, что нужно быть осторожным. (Сияние)",
	"Если вы хотите написать книгу, просто начните писать. (Как писать книги)",
	"Иногда лучше просто сделать шаг назад и подумать, прежде чем действовать. (Мгла)",
	"Не позволяйте страху управлять вами; сделайте первый шаг. (Кладбище домашних животных)",
	"Важно знать, когда следует остановиться. (Сияние)",
	"Каждый человек имеет право на свои страхи, но не стоит позволять им контролировать вашу жизнь. (Темная башня)",
	"Если вы хотите изменить мир, начните с себя. (Мечта Кассиопеи)",
	"Не бойтесь своих идей; они могут привести вас к успеху. (11/22/63)",
	"Иногда нужно рискнуть, чтобы получить то, что вы хотите. (Томминокеры)",
	"Слушайте свое сердце; оно знает, что вам нужно. (Зеленая миля)",
	"Не позволяйте другим определять ваши возможности. (Сияние)",
	"Ваша жизнь — это ваша история; пишите ее так, как хотите. (Долгая прогулка)",
	"Не бойтесь провалов; они — часть пути к успеху. (Роза Марена)",
	"Каждый имеет право на свои мечты; следуйте за ними. (Мертвые зоны)",
	"Важно уметь прощать — как других, так и себя. (Сердца в Атлантиде)",
	"Не позволяйте прошлому определять ваше будущее. (Оно)",
	"Иногда лучше оставить все как есть, чем вмешиваться. (Под куполом)",
	"Ищите вдохновение в каждом дне; оно повсюду вокруг вас. (Нужные вещи)",
	"Смелость — это не отсутствие страха, а способность действовать несмотря на него. (Ловец снов)",
	"Не забывайте о том, что важно для вас. (Сияние)",
	"Каждый день — это новая возможность изменить свою жизнь. (Кладбище домашних животных)",
	"Делайте то, что любите; это приведет к счастью. (Темная башня)",
	"Не бойтесь задавать вопросы; они ведут к пониманию. (Доктор Сон)",
	"Ваши ошибки — это ваши учителя; учитесь на них. (Мгла)",
	"Иногда нужно просто отпустить и двигаться дальше. (Зеленая миля)",
	"Доброта может изменить мир вокруг вас. (Сердца в Атлантиде)",
	"Не позволяйте сомнениям останавливать вас от достижения целей. (11/22/63)",
	"Следуйте своим инстинктам; они часто правы. (Оно)",
	"Важно помнить: каждый из нас уникален и ценен. (Под куполом)",
	"Стремитесь к лучшему, но принимайте себя таким, какой вы есть. (Роза Марена)",
}

func connectWithTelegram() {
	var err error
	if bot, err = tgbotapi.NewBotAPI(TOKEN); err != nil {
		panic("can't connect to Telegram")
	}
}

func isMessageForFortuneTeller(update *tgbotapi.Update) bool {
	if update.Message == nil || update.Message.Text == "" {
		return false
	}

	msgInLowerCase := strings.ToLower(update.Message.Text)
	for _, name := range fortuneTellerNames {
		if strings.Contains(msgInLowerCase, name) {
			return true
		}
	}
	return false
}

func sendMessage(chatId int64, msg string) {
	msgConfig := tgbotapi.NewMessage(chatId, msg)
	bot.Send(msgConfig)
}

func getFortuneTellersAnswer() string {
	index := rand.Intn(len(answers))
	return answers[index]
}

func sendAnswer(update *tgbotapi.Update) {
	msg := tgbotapi.NewMessage(update.Message.Chat.ID, getFortuneTellersAnswer())
	msg.ReplyToMessageID = update.Message.MessageID
	bot.Send(msg)
}

func main() {
	connectWithTelegram()
	updateConfig := tgbotapi.NewUpdate(0)
	for update := range bot.GetUpdatesChan(updateConfig) {
		if update.Message != nil {
			if update.Message.Text == "/start" {
				sendMessage(update.Message.Chat.ID,
					"Задай свой вопрос, назвав меня по имени. Ответом на вопрос должны быть \"Да\" либо \"Нет\"."+
						" Например: \"Кинг, я готов сменить работу?\" или \"Стивен, я действительно хочу отправиться на эту вечеринку?\"")
			} else if isMessageForFortuneTeller(&update) {
				sendAnswer(&update)
			}
		}
	}
}
