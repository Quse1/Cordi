package main

import "fmt"

func addBinary(a string, b string) {

	if len(a) > len(b) {
		for len(a) != len(b) {
			b = "0" + b
			fmt.Println(b)
		}
	} else {
		for len(a) != len(b) {
			a = "0" + a
		}
	}
	for i := len(a) - 1; i >= 0; i-- {
		fmt.Println(string(a[i]), string(b[i]))

	}
}
func main() {
	a := "11"
	b := "1"
	addBinary(a, b)

}
